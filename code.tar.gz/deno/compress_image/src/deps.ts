import {
   encode as base64Encode,
   decode as base64Decode
} from "https://deno.land/std@0.82.0/encoding/base64.ts"

export { base64Encode, base64Decode }