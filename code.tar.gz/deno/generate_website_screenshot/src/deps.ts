import {
    decode as base64Decode,
    encode as base64Encode,
  } from 'https://deno.land/std@0.82.0/encoding/base64.ts';
 
export { base64Decode, base64Encode };